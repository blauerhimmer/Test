#include "config.h"
#include "functions.h"

char algorithm_type[] = "obstcale";




double thetaCaculator(int counter)//concentration_1 在左
{
    double temp_theta = asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2;
    ROS_INFO("The origin theta is %f",temp_theta);

    ROS_INFO("Last:%f   Current:%f",array_of_expertiment_data[counter-1].concentration.concentration_3,array_of_expertiment_data[counter].concentration.concentration_3);
    if  (array_of_expertiment_data[counter].concentration.concentration_3 >array_of_expertiment_data[counter-1].concentration.concentration_3)
        {
            temp_theta+=0;//当上一步时两个传感器浓度都大于当前步，则方向不变。
            ROS_INFO("Theta hasn't changed.");
        }
    else
        {
            temp_theta+=(double(rand()%1000)/1000-0.5)*2*M_PI;
            //否则对theta根据两个传感器的差值进行运算
        }
    
    temp_theta = fabs(temp_theta > M_PI) ? (temp_theta > 0 ? temp_theta - 2*M_PI : temp_theta + 2*M_PI) : temp_theta;
    
    ROS_INFO("The transformed theta is %f",temp_theta); 
    return temp_theta; 
}


int main(int argc, char *argv[])
{
    srand(time(NULL)+rand());

    //初始化节点
    ros::init(argc, argv, "finder"); 

    //定义传感器订阅
    ros::NodeHandle n;
    ros::Subscriber experiment_data_sub;
    experiment_data_sub = n.subscribe("experiment_data", 1, experiment_data_subCallback);
    
    //定义actionlib的client
    MoveBaseClient ac("move_base", true);

    //等待action server响应
    while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
    }

    //定义tf相关常量
    tf::TransformListener listener;
    tf::StampedTransform transform;
    std::string odom_frame="/map";
    std::string base_frame="/base_footprint";//两个frame的名称很重要

    //tf坐标转换
    try
    {
        listener.waitForTransform(odom_frame, base_frame, ros::Time(), ros::Duration(2.0) );
    }
    catch(tf::TransformException& ex)
    {
        ROS_ERROR("%s", ex.what());
    }
    
    ros::spinOnce();
    array_of_expertiment_data[0] = temp_of_expertiment_data;//起点赋值,使得起点的坐标是实时的，以后的坐标就都根据该点进行推算

    //开始寻源
    for(counter=0;ros::ok();counter++)
    {   
        ROS_INFO("SEARCHING No.%d",counter); 
        ROS_INFO("-----x_goal=%f,y_goal=%f,theta_goal=%f------" ,   array_of_expertiment_data[counter].position.target_pose.pose.position.x,
                                                                    array_of_expertiment_data[counter].position.target_pose.pose.position.y,
                                                                    asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2); 
        if(counter>0)
            {
                sendGoal(ac,array_of_expertiment_data[counter].position);
            }
            //如果是第一轮，就直接开始读酒精浓度，否则发送上一步计算好的坐标位置
        if(isNearSource(array_of_expertiment_data[counter].position.target_pose.pose.position.x,
                array_of_expertiment_data[counter].position.target_pose.pose.position.y))
            break;
        ros::Duration(3.0).sleep();
        record_seconds = 3;
        wait_seconds = 1;
        getConcentration(array_of_expertiment_data[counter]);

        if(counter == 0)//给下一个目标点赋值
            {
                theta = asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2;   
                assignGoal(array_of_expertiment_data, counter, step_length, theta);
            }//如果是第一步，就直行一个步长
        else
            {                
                theta = thetaCaculator(counter);   
                assignGoal(array_of_expertiment_data, counter, step_length, theta);
                ROS_INFO("-----counter+1=%d,x_origin=%f,y_origin=%f,theta_origin=%f------",   counter+1,
                                                                            array_of_expertiment_data[counter+1].position.target_pose.pose.position.x,
                                                                            array_of_expertiment_data[counter+1].position.target_pose.pose.position.y,
                                                                            theta);
                obstacleAvoiding(array_of_expertiment_data, counter, theta);
                ROS_INFO("-----counter+1=%d,x_changed=%f,y_changed=%f,theta_changed=%f------", counter+1,
                                                                            array_of_expertiment_data[counter+1].position.target_pose.pose.position.x,
                                                                            array_of_expertiment_data[counter+1].position.target_pose.pose.position.y,
                                                                            asin(array_of_expertiment_data[counter+1].position.target_pose.pose.orientation.z)*2);
            }
    }

    
    frw(array_of_expertiment_data, counter, algorithm_type);
    

}