#include "config.h"
#include "functions.h"

char algorithm_type[] = "hex_path"; 
bool anticlock[100];

double thetaCaculator(int counter)//concentration_1 在正前方，2,3,4逆时针旋转
{
    double temp_theta = asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2;
    ROS_INFO("The origin theta is %f",temp_theta); 
    int switch_choice=1;
    if(counter >= 3)
        {
            if
            (
                (
                    (array_of_expertiment_data[counter-2].concentration.concentration_4 > array_of_expertiment_data[counter-1].concentration.concentration_4)
                    &&
                    (anticlock[counter-1])
                )
                ||
                (
                    (array_of_expertiment_data[counter-2].concentration.concentration_4 < array_of_expertiment_data[counter-1].concentration.concentration_4)
                    &&
                    (!anticlock[counter-1])
                )
            )
                switch_choice = -1,anticlock[counter] = true;
            else
                switch_choice = 1,anticlock[counter] = false;
        }
    else
        {
            switch_choice = ((rand()%2) == 0) ? (-1) : 1;
            anticlock[counter] = (switch_choice == -1) ? true : false; 
        }
    
    if(switch_choice == -1)
        {
            temp_theta = temp_theta + (1.0/3.0)*3.141593;
            ROS_INFO("Anticlockwise!!!!!!!!!");
        }
    else
        {
            temp_theta = temp_theta - (1.0/3.0)*3.141593;
            ROS_INFO("Clockwise!!!!!!!!!");
        }
    temp_theta = (fabs(temp_theta) > M_PI) ? (temp_theta > 0 ? temp_theta - 2*M_PI : temp_theta + 2*M_PI) : temp_theta;
    ROS_INFO("choice %d",switch_choice); 
    
    ROS_INFO("The transformed theta is %f",temp_theta); 
    return temp_theta; 
}



float getAverage()
{
    ros::spinOnce();
    return (temp_of_expertiment_data.concentration.concentration_1+
            temp_of_expertiment_data.concentration.concentration_2+
            temp_of_expertiment_data.concentration.concentration_3+
            temp_of_expertiment_data.concentration.concentration_4)/4;
}


int main(int argc, char *argv[])
{
    srand(time(NULL)+rand());//随机种子
    //创建实验数据记录文件,并以日期命名

    
    //初始化节点
    ros::init(argc, argv, "finder"); 

    //定义传感器订阅
    ros::NodeHandle n;
    ros::Subscriber experiment_data_sub;
    experiment_data_sub = n.subscribe("experiment_data", 1, experiment_data_subCallback);
    
    //定义actionlib的client
    MoveBaseClient ac("move_base", true);

    //等待action server响应
    while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
    }

    //定义tf相关常量
    tf::TransformListener listener;
    tf::StampedTransform transform;
    std::string odom_frame="/map";
    std::string base_frame="/base_footprint";//两个frame的名称很重要

    //tf坐标转换
    try
    {
        listener.waitForTransform(odom_frame, base_frame, ros::Time(), ros::Duration(2.0) );
    }
    catch(tf::TransformException& ex)
    {
        ROS_ERROR("%s", ex.what());
    }
    

    // while(1)
    // {
    //     ros::spinOnce();
    //     ros::Duration(0.5).sleep();
    //     ROS_INFO_STREAM(temp_of_expertiment_data.concentration.concentration_4);
    //     if(temp_of_expertiment_data.concentration.concentration_4 > 35)
    //         break;
    // }

    tricker();

    
    ros::spinOnce();
    array_of_expertiment_data[0] = temp_of_expertiment_data;//起点赋值,使得起点的坐标是实时的，以后的坐标就都根据该点进行推算

    for(counter=0;ros::ok()&&(counter<101);counter++)
    {   
        ROS_INFO("SEARCHING No.%d",counter); 
        ROS_INFO("-----x_goal=%f,y_goal=%f,theta_goal=%f------" ,   array_of_expertiment_data[counter].position.target_pose.pose.position.x,
                                                                    array_of_expertiment_data[counter].position.target_pose.pose.position.y,
                                                                    asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2); 
        if(counter>0)
        {
            sendGoal(ac,array_of_expertiment_data[counter].position);
        }//如果是第一轮，就直接开始读酒精浓度，否则发送上一步计算好的坐标位置

        getConcentration(array_of_expertiment_data[counter]);

        if(isNearSource(array_of_expertiment_data[counter].position.target_pose.pose.position.x,
                array_of_expertiment_data[counter].position.target_pose.pose.position.y))
            break;
        
        

        if(counter == 0)//给下一个目标点赋值
            {
                theta = asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2;   
                assignGoal(array_of_expertiment_data, counter, step_length, theta);
            }//如果是第一步，就直行一个步长
        else
            {                
                theta = thetaCaculator(counter);   
                assignGoal(array_of_expertiment_data, counter, step_length, theta);
                obstacleAvoiding(array_of_expertiment_data, counter, theta);
            }
    }

    frw(array_of_expertiment_data, counter, algorithm_type);
    

}