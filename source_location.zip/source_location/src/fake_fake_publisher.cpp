#include "config.h"


//自定义消息类型，用于双传感器

source_location::experiment_data experiment_data;

int main(int argc, char *argv[])
{
    //创建实验数据记录文件,并以日期命名


    //初始化节点
    ros::init(argc, argv, "experiment_data_publisher"); 

    //定义传感器订阅
    ros::NodeHandle n;
    ros::Publisher data_pub = n.advertise<source_location::experiment_data>("experiment_data", 10);
    
    ros::Rate loopRate(10);

    while (ros::ok())
    {
        
        experiment_data.position.target_pose.header.frame_id = "map";
        experiment_data.position.target_pose.header.stamp = ros::Time::now();
        experiment_data.position.target_pose.pose.position.x = 1; 
        experiment_data.position.target_pose.pose.position.y = 1;
        experiment_data.position.target_pose.pose.orientation.z = 1;
        experiment_data.position.target_pose.pose.orientation.w = 1;

        //ros::spinOnce();
        experiment_data.concentration.concentration_1 = 1000.0/sqrt(pow(experiment_data.position.target_pose.pose.position.x-X_SOURCE_POSITION,2)+pow(experiment_data.position.target_pose.pose.position.y-Y_SOURCE_POSITION,2));
        experiment_data.concentration.concentration_2 = 1000.0/sqrt(pow(experiment_data.position.target_pose.pose.position.x-X_SOURCE_POSITION,2)+pow(experiment_data.position.target_pose.pose.position.y-Y_SOURCE_POSITION,2));
        experiment_data.concentration.concentration_3 = 1000.0/sqrt(pow(experiment_data.position.target_pose.pose.position.x-X_SOURCE_POSITION,2)+pow(experiment_data.position.target_pose.pose.position.y-Y_SOURCE_POSITION,2));
        experiment_data.concentration.concentration_4 = 1000.0/sqrt(pow(experiment_data.position.target_pose.pose.position.x-X_SOURCE_POSITION,2)+pow(experiment_data.position.target_pose.pose.position.y-Y_SOURCE_POSITION,2));
        data_pub.publish(experiment_data);


        loopRate.sleep();
    }
    
}