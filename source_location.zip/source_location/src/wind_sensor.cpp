#include <ros/ros.h> 
#include <serial/serial.h>  //ROS已经内置了的串口包 
#include <std_msgs/String.h> 
#include <source_location/wind_information.h>
#include <fstream>

using namespace std;




  
int main (int argc, char** argv) 
{ 
    //初始化节点 
    ros::init(argc, argv, "serial_example_node"); 
    //声明节点句柄 
    ros::NodeHandle nh; 
    //发布主题 
    ros::Publisher wind_pub = nh.advertise<source_location::wind_information>("wind_information", 20);
    //声明串口对象
    serial::Serial ser;

    try 
    { 
    //设置串口属性，并打开串口 
        ser.setPort("/dev/ttyUSB0"); 
        ser.setBaudrate(9600); 
        serial::Timeout to = serial::Timeout::simpleTimeout(1000); 
        ser.setTimeout(to); 
        ser.open(); 
    } 
    catch (serial::IOException& e) 
    { 
        ROS_ERROR_STREAM("Unable to open port "); 
        return -1; 
    } 
  
    //检测串口是否已经打开，并给出提示信息 
    if(ser.isOpen()) 
    { 
        ROS_INFO_STREAM("Serial Port initialized"); 
    } 
    else 
    { 
        return -1; 
    } 
    source_location::wind_information wind_information;
    //指定循环的频率 
    ros::Rate loop_rate(20); 
    while(ros::ok()) 
    { 
        uint8_t request[8]={0x01,0x03,0x00,0x00,0x00,0x02,0xC4,0x0B};
        ROS_INFO_STREAM("Writing to serial port" <<request); 
        
        
        ofstream fout("str",ios::app);
        fout<<"velocity"<<"\t"<<"direction"<<"\n";

        ser.write(request,8);   //发送串口数据 
        if(ser.available())
        { 
            ROS_INFO_STREAM("Reading from serial port\n"); 
            std_msgs::String result; 
            result.data = ser.read(ser.available());
            ROS_INFO_STREAM("Read: "<<result.data);
            ROS_INFO_STREAM(""<<(unsigned char)result.data[0]);
            int a[8];
            for(int i=0;i<8;i++)
               {
                   a[i]=(unsigned char)result.data[i];
               }
            ROS_INFO("%02x %02x %02x %02x %02x %02x %02x %02x",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]); 
            ROS_INFO("Wind Speed: %f",(float)((a[3]<<8)+a[4])/100);
            ROS_INFO("Wind Direction: %f",(float)((a[5]<<8)+a[6]));
            ROS_INFO("%d %d %d %d %d %d %d %d",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]); 
            
            //ROS_INFO("Wind Speed: %d-%d",a[3],a[4]);
            //ROS_INFO("Wind Direction: %d-%d",a[5],a[6]);
            wind_information.speed = (float)((a[3]<<8)+a[4])/100;
            wind_information.direction = (float)((a[5]<<8)+a[6]);
            wind_pub.publish(wind_information);
            fout<<wind_information.speed<<"\t"<<wind_information.direction<<"\n";

        } 

        //处理ROS的信息，比如订阅消息,并调用回调函数 
        loop_rate.sleep(); 
  
    } 
} 