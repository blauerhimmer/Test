#include "config.h"
#include "functions.h"

char algorithm_type[] = "obscale";




double thetaCaculator(int counter)//concentration_1 在左
{
    double temp_theta = asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2;
    ROS_INFO("The origin theta is %f",theta);

    ROS_INFO("Last:%f   Current:%f",array_of_expertiment_data[counter-1].concentration.concentration_3,array_of_expertiment_data[counter].concentration.concentration_3);
    if  (array_of_expertiment_data[counter].concentration.concentration_3 >array_of_expertiment_data[counter-1].concentration.concentration_3)
        {
            theta+=0;//当上一步时两个传感器浓度都大于当前步，则方向不变。
            ROS_INFO("Theta hasn't changed.");
        }
    else
        {
            theta+=(double(rand()%1000)/1000-0.5)*2*M_PI;
            //否则对theta根据两个传感器的差值进行运算
        }
    
    theta = fabs(theta > M_PI) ? (theta > 0 ? theta - 2*M_PI : theta + 2*M_PI) : theta;
    
    ROS_INFO("The transformed theta is %f",theta); 
    return theta; 
}


int main(int argc, char *argv[])
{
    srand(time(NULL)+rand());

    //初始化节点
    ros::init(argc, argv, "finder"); 

    //定义传感器订阅
    ros::NodeHandle n;
    ros::Subscriber experiment_data_sub;
    experiment_data_sub = n.subscribe("experiment_data", 1, experiment_data_subCallback);
    
    //定义actionlib的client
    MoveBaseClient ac("move_base", true);

    //等待action server响应
    while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
    }

    //定义tf相关常量
    tf::TransformListener listener;
    tf::StampedTransform transform;
    std::string odom_frame="/map";
    std::string base_frame="/base_footprint";//两个frame的名称很重要

    //tf坐标转换
    try
    {
        listener.waitForTransform(odom_frame, base_frame, ros::Time(), ros::Duration(2.0) );
    }
    catch(tf::TransformException& ex)
    {
        ROS_ERROR("%s", ex.what());
    }
    

    //开始寻源
    for(counter=0;
        ros::ok()&&!isNearSource(   array_of_expertiment_data[counter].position.target_pose.pose.position.x,
                                    array_of_expertiment_data[counter].position.target_pose.pose.position.y);
        counter++)
    {   
        ROS_INFO("SEARCHING No.%d",counter); 
        
        if(counter%2==0)
            {
                array_of_expertiment_data[counter].position.target_pose.pose.position.x = 0;

                array_of_expertiment_data[counter].position.target_pose.pose.position.y = 0;

                array_of_expertiment_data[counter].position.target_pose.pose.orientation.w = 1;

                array_of_expertiment_data[counter].position.target_pose.header.frame_id = "map";

                array_of_expertiment_data[counter].position.target_pose.header.stamp = ros::Time::now();
            }
        else
            {
                array_of_expertiment_data[counter].position.target_pose.pose.position.x = -1;

                array_of_expertiment_data[counter].position.target_pose.pose.position.y = 0;

                array_of_expertiment_data[counter].position.target_pose.pose.orientation.w = 1;

                array_of_expertiment_data[counter].position.target_pose.header.frame_id = "map";

                array_of_expertiment_data[counter].position.target_pose.header.stamp = ros::Time::now();
            }
            
        sendGoal(ac,array_of_expertiment_data[counter].position);
        ros::Duration(15.0).sleep();
            //如果是第一轮，就直接开始读酒精浓度，否则发送上一步计算好的坐标位置
        
            

        
    }

    
    frw(array_of_expertiment_data, counter, algorithm_type);
    

}