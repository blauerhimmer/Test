#include "config.h"


//自定义消息类型，用于双传感器

source_location::experiment_data experiment_data;


void sensor_subCallback(const source_location::alcohol_concentration &msg)
{
    experiment_data.concentration = msg;
}



int main(int argc, char *argv[])
{
    //创建实验数据记录文件,并以日期命名
    time_t now ;
    struct tm *tm_now ;
    time(&now) ;
    tm_now = localtime(&now) ;
	char str[100];
	sprintf(str,"/home/jamerri/experiment_data/alco-%d-%d-%d-%d-%d-%d.txt",
	tm_now->tm_year+1900, tm_now->tm_mon+1, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	ofstream fout(str,ios::app);


    //初始化节点
    ros::init(argc, argv, "experiment_data_publisher"); 

    //定义传感器订阅
    ros::NodeHandle n;
    ros::Subscriber sensor_sub = n.subscribe("alcohol_concentration", 1, sensor_subCallback);
    ros::Rate loopRate(10);
    fout<<"x"<<"\t"<<"y"<<"\t"<<"z"<<"\t"<<"w"<<"\t"<<"concentration_1"<<"\t"<<"concentration_2"<<"\t"<<"concentration_3"<<"\t"<<"concentration_4"<<"\n";

    while (ros::ok())
    {


        ros::spinOnce();

        ROS_INFO_STREAM("Read: "<<experiment_data.concentration.concentration_1
                                <<"\t"<<experiment_data.concentration.concentration_2
                                <<"\t"<<experiment_data.concentration.concentration_3
                                <<"\t"<<experiment_data.concentration.concentration_4);

        fout<<experiment_data.concentration.concentration_1<<"\t"
            <<experiment_data.concentration.concentration_2<<"\t"
            <<experiment_data.concentration.concentration_3<<"\t"
            <<experiment_data.concentration.concentration_4<<"\n";

        loopRate.sleep();
    }
    

    fout.close();  
}