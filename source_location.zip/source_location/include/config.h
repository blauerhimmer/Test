#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Odometry.h>
#include <ros/time.h>
#include <tf/transform_listener.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

//包含了一些自定义的消息类型
#include <source_location/experiment_data.h>
#include <source_location/alcohol_concentration.h>


#include <string.h>
#include <fstream>
#include <cmath>
#include <ctime>
#include <iostream>
#include <time.h>
#include <stdio.h>




//定义了一些参数,这些参数是机器人的移动范围限制和源的坐标
#define X_MIN -0.5
#define X_MAX 4.0

#define Y_MIN -1.6
#define Y_MAX 1.8

#define SEARCHING_TIME 30

#define X_SOURCE_POSITION 3.45
#define Y_SOURCE_POSITION -0.8


using namespace std;

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
typedef move_base_msgs::MoveBaseGoal MoveBaseGoal;

source_location::experiment_data array_of_expertiment_data[150];
source_location::experiment_data temp_of_expertiment_data;

int successed_time=0;
float step_length = 0.3;
int counter;
float theta;
int success_config = 1;
int record_seconds = 10;//record_seconds要大于wait_seconds
int wait_seconds = 3;

