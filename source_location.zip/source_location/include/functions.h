void experiment_data_subCallback(const source_location::experiment_data &msg)
{
    temp_of_expertiment_data = msg;
    ROS_INFO("%f----%f----%f----%f",        temp_of_expertiment_data.concentration.concentration_1,
                                            temp_of_expertiment_data.concentration.concentration_2,
                                            temp_of_expertiment_data.concentration.concentration_3,
                                            temp_of_expertiment_data.concentration.concentration_4
                                            );
}

/*void tricker()
{
    while(1)
    {
        ros::spinOnce();
        ros::Duration(0.5).sleep();
        ROS_INFO_STREAM("WAITING_____Concentration = " << temp_of_expertiment_data.concentration.concentration_4);          
        if(temp_of_expertiment_data.concentration.concentration_4 > 32)
            break;
    }
}*/
/*void tricker()
{
    double tricker = 0;
    int time = 0;
    while(1)
    {
        time += 1;

        ros::spinOnce();
        ros::Duration(0.5).sleep();
        tricker += temp_of_expertiment_data.concentration.concentration_4;
        ROS_INFO_STREAM("WAITING");
        ROS_INFO_STREAM("Time = " << time);
        ROS_INFO_STREAM("Concentration = " << temp_of_expertiment_data.concentration.concentration_4);
        ROS_INFO_STREAM("Tricker = " << tricker);
        if(time % 10 == 0)//time到10的时候将tricker归零
            tricker = 0;
        else if(tricker / 10 > 30)
                break;
    }
}*/
/*void tricker()
{
    while(1)
    {
        ros::spinOnce();
        ros::Duration(0.5).sleep();
        ROS_INFO_STREAM("WAITING_____Concentration = " << temp_of_expertiment_data.concentration.concentration_4);          
        if(temp_of_expertiment_data.concentration.concentration_4 > 32)
            break;
    }
}*/

void tricker()
{
    //double tricker = 0;
    int time = 1;
    while(1)
    {
        //time = 1;

        ros::spinOnce();
        ros::Duration(0.5).sleep();
        //tricker += temp_of_expertiment_data.concentration.concentration_4;
        ROS_INFO_STREAM("WAITING");
        ROS_INFO_STREAM("Time = " << time);
        ROS_INFO_STREAM("Concentration = " << temp_of_expertiment_data.concentration.concentration_4);
        //ROS_INFO_STREAM("Tricker = " << tricker);
        if(temp_of_expertiment_data.concentration.concentration_4 >= 28)
            time += 1;
        else
            time = 1;
        if(time > 5)
            break;
    }
}

bool isNearSource(double x,double y)
{
    //ROS_INFO("x=%f,y=%f",x,y);
    if((fabs(x-X_SOURCE_POSITION)<0.35)&&(fabs(y-Y_SOURCE_POSITION)<0.35))
        {
            ROS_INFO("Source~~~~");
            return true;
        }
    else
            return false;
}

void assignGoal(source_location::experiment_data  array[],int counter,float length,float temp_theta)
{
    array[counter+1].position.target_pose.pose.position.x
    = array[counter].position.target_pose.pose.position.x
    + length*cos(temp_theta);

    array[counter+1].position.target_pose.pose.position.y
    = array[counter].position.target_pose.pose.position.y
    + length*sin(temp_theta);

    array[counter+1].position.target_pose.pose.orientation.z
    = sin(temp_theta/2.0);

    array[counter+1].position.target_pose.pose.orientation.w
    = cos(temp_theta/2.0);

    array[counter+1].position.target_pose.header.frame_id = "map";

    array[counter+1].position.target_pose.header.stamp = ros::Time::now();
}

void sendGoal(MoveBaseClient& actionlibClient,MoveBaseGoal goal)
{
    
    actionlibClient.sendGoal(goal);
    actionlibClient.waitForResult(ros::Duration(45.0));
    if(actionlibClient.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        {
            ROS_INFO("Goal reached.");
            successed_time++;
            success_config = 1;
        }
    else
        {
            ROS_INFO("Failed to reach the goal."); 
            success_config = 0;
        }
}

void frw(source_location::experiment_data  array[],int counter_max,char algorithm_type[])
{
    int counter;
    time_t now;
    struct tm *tm_now ;
    time(&now) ;
    tm_now = localtime(&now) ;
	char str[100];
	sprintf(str,"/home/six/sl_ws/src/source_location/experiment_data/%s-%d-%d-%d-%d-%d-%d.txt"
	        ,algorithm_type,tm_now->tm_year+1900, tm_now->tm_mon+1, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	ROS_INFO("Saving data to %s",str);
    ofstream fout(str,ios::app);
    fout<<"algorithm_type:"<<algorithm_type<<"\n";
    fout<<"X_max:"<<X_MAX<<"\n";
    fout<<"X_min:"<<X_MIN<<"\n";
    fout<<"Y_MAX:"<<Y_MAX<<"\n";
    fout<<"Y_MIN:"<<Y_MIN<<"\n";
    fout<<"X_SOURCE_POSITION:"<<X_SOURCE_POSITION<<"\n";
    fout<<"Y_SOURCE_POSITION:"<<Y_SOURCE_POSITION<<"\n";
    fout<<tm_now->tm_mon+1<<tm_now->tm_mday<<tm_now->tm_hour<<tm_now->tm_min<<"\n";
    fout<<"counter"<<"\t"<<"x"<<"\t"<<"y"<<"\t"<<"theta"<<"\t"<<"z"<<"\t"<<"w"<<"\t"<<"time"<<"\t"<<"C_1"<<"\t"<<"C_2"<<"\t"<<"C_3"<<"\t"<<"C_4"<<"\n";
    for(counter=0;counter<counter_max+1;counter++)
    {
        fout<<counter<<"\t"
            <<array[counter].position.target_pose.pose.position.x<<"\t"
            <<array[counter].position.target_pose.pose.position.y<<"\t"
            <<asin(array_of_expertiment_data[counter].position.target_pose.pose.orientation.z)*2<<"\t"
            <<array[counter].position.target_pose.pose.orientation.z<<"\t"
            <<array[counter].position.target_pose.pose.orientation.w<<"\t"
            <<array[counter].position.target_pose.header.stamp<<"\t"
            <<array[counter].concentration.concentration_1<<"\t"
            <<array[counter].concentration.concentration_2<<"\t"
            <<array[counter].concentration.concentration_3<<"\t"
            <<array[counter].concentration.concentration_4<<"\t"
            <<array[counter].variance_1<<"\t"
            <<array[counter].variance_2<<"\t"
            <<array[counter].variance_3<<"\t"
            <<array[counter].variance_3<<"\n";
    }
    fout.close();
    ROS_INFO("Data saved.");
}

void getConcentration(source_location::experiment_data &data)
{
    float sensor_temp_1=0;
    float sensor_temp_2=0;
    float sensor_temp_3=0;
    float sensor_temp_4=0;
    
    for(int s_i=0;s_i<record_seconds;s_i++)
    {
        ros::spinOnce();
        //fout_details<<i<<sensor_data.concentration_1<<sensor_data.concentration_2;
        if(s_i>wait_seconds-1)//前五秒的数据丢掉,避免机器人本身移动对气流的影响
        {
            sensor_temp_1 += temp_of_expertiment_data.concentration.concentration_1;
            sensor_temp_2 += temp_of_expertiment_data.concentration.concentration_2;
            sensor_temp_3 += temp_of_expertiment_data.concentration.concentration_3;
            sensor_temp_4 += temp_of_expertiment_data.concentration.concentration_4;
        }

        ros::Duration(1.0).sleep();
    }
    //data = temp_of_expertiment_data;//坐标等信息被传入
    //注释上一行，为了使用HEX-PATH。也就是说除了第一次是采取实时坐标，其他时间都用根据第一个坐标推算出来的六边形的坐标
    data.concentration.concentration_1 = sensor_temp_1/(record_seconds-wait_seconds);
    data.concentration.concentration_2 = sensor_temp_2/(record_seconds-wait_seconds);
    data.concentration.concentration_3 = sensor_temp_3/(record_seconds-wait_seconds);
    data.concentration.concentration_4 = sensor_temp_4/(record_seconds-wait_seconds);
}

float get_variance(float a[],int n)  
{  
    float mean,sum1=0;  
    int i;  
    for(i=0;i<=n-1;i++)   
    {   
        sum1+=a[i];   
    }   
    mean=sum1/n;  
    
    float variance,sum2=0;  
    for (i=0;i<=n-1;i++)   
    {   
        sum2+=(a[i]-mean)*(a[i]-mean);   
    }   
    variance=sum2/n;  
    return variance;  
} 

void getVariance(source_location::experiment_data &data)
{
    float sensor_temp_1[1000]={0};
    float sensor_temp_2[1000]={0};
    float sensor_temp_3[1000]={0};
    float sensor_temp_4[1000]={0};
    int iter = 0;
    for(iter=0;iter<5;iter++)
    {
        ros::Duration(1.0).sleep();
        ROS_INFO("Waitting %d seconds.", iter);
    }
    ROS_INFO("Recording");
    ros::Rate loopRate_variance(100);
    for(iter = 0;iter < 1000;iter++)
    {
        if((iter+1)%200 == 0)
            ROS_INFO("%d / 5", (iter+1)/200);
        ros::spinOnce();
        sensor_temp_1[iter] = temp_of_expertiment_data.concentration.concentration_1;
        sensor_temp_2[iter] = temp_of_expertiment_data.concentration.concentration_2;
        sensor_temp_3[iter] = temp_of_expertiment_data.concentration.concentration_3;
        sensor_temp_4[iter] = temp_of_expertiment_data.concentration.concentration_4;
        //ROS_INFO("----%f----%f----%f----%f----", sensor_temp_1[iter],sensor_temp_2[iter],sensor_temp_3[iter],sensor_temp_4[iter]);
        data.concentration.concentration_1 += sensor_temp_1[iter];
        data.concentration.concentration_2 += sensor_temp_2[iter];
        data.concentration.concentration_3 += sensor_temp_3[iter];
        data.concentration.concentration_4 += sensor_temp_4[iter];
        loopRate_variance.sleep();
    }
    //data = temp_of_expertiment_data;//坐标等信息被传入
    //注释上一行，为了使用HEX-PATH。也就是说除了第一次是采取实时坐标，其他时间都用根据第一个坐标推算出来的六边形的坐标
    data.concentration.concentration_1 = data.concentration.concentration_1/1000.0;
    data.concentration.concentration_2 = data.concentration.concentration_2/1000.0;
    data.concentration.concentration_3 = data.concentration.concentration_3/1000.0;
    data.concentration.concentration_4 = data.concentration.concentration_4/1000.0;
    data.variance_1 = get_variance(sensor_temp_1,1000);
    data.variance_2 = get_variance(sensor_temp_2,1000);
    data.variance_3 = get_variance(sensor_temp_3,1000);
    data.variance_4 = get_variance(sensor_temp_4,1000);
}

double getMax(double a[],int n)  
{  
    double max = 0;  
    int i;  
    for(i=0;i<=n-1;i++)   
    {   
        if(a[i]>max)
            max = a [i];
        else
            max = max;  
    }   
      
    return max;
} 

bool isInRange(double x,double y)
{
    //ROS_INFO("x=%f,y=%f",x,y);
    if((x>X_MIN)&&(x<X_MAX)&&(y>Y_MIN)&&(y<Y_MAX))
        return true;
    else
        {
            ROS_INFO("The goal is not in the range.");
            return false;
        }
}
void obstacleAvoiding(source_location::experiment_data array[],int counter,double temp_theta)
{

    double x = array[counter+1].position.target_pose.pose.position.x;
    double y = array[counter+1].position.target_pose.pose.position.y;
    double x0 = array[counter].position.target_pose.pose.position.x;
    double y0 = array[counter].position.target_pose.pose.position.y;
    ROS_INFO("obstacleAvoiding************");
    ROS_INFO("obstacle_x = %f,obstacle_y = %f",x,y);
    if(!isInRange(x,y))
    {
        
        ROS_INFO("Oppsssss");
        /*if( x > X_MAX )
            {
                x = X_MAX - abs(x-X_MAX) - 0.25;
                temp_theta = (temp_theta>=0)? (M_PI-temp_theta):(-M_PI-temp_theta);
            }
        else if( x < X_MIN )
            {
                x = X_MIN + abs(x-X_MIN) + 0.25;
                temp_theta = (temp_theta>=0)? (M_PI-temp_theta):(-M_PI-temp_theta);
            }


        if( y > Y_MAX )
            {
                y = Y_MAX - abs(y-Y_MAX) - 0.25;
                temp_theta = -temp_theta;
            }
        else if( y < Y_MIN )
            {
                y = Y_MIN + abs(y-Y_MIN) + 0.25;
                temp_theta = -temp_theta;
            }*/
        if(( y > Y_MAX ) && ( x < X_MIN || x > X_MAX))   //上面两个角落
            {
               temp_theta =  ( -M_PI + temp_theta );
               x = x + 0.3 * cos(temp_theta);
               y = y + 0.3 * sin(temp_theta);
            }
        if(( y < Y_MIN ) && ( x < X_MIN || x > X_MAX))   //下面面两个角落
            {
               temp_theta =  ( M_PI + temp_theta );
               x = x + 0.3 * cos(temp_theta);
               y = y + 0.3 * sin(temp_theta);
            }                                                                                
        if(( y > Y_MAX ||  y < Y_MIN  ) &&  x > X_MIN && x < X_MAX)   //上下面中间
            {
               temp_theta =  - temp_theta ;
               y = y + 2 * (y0-y);
            }   
        if(( x > X_MAX ||  x < X_MIN  ) &&  y > Y_MIN && y < Y_MAX)   //左右面中间
            {
               temp_theta =  M_PI- temp_theta ;
               x = x + 2 * (x0-x);
            }            
            

        

        array[counter+1].position.target_pose.pose.orientation.z
        = sin(temp_theta/2.0);

        array[counter+1].position.target_pose.pose.orientation.w
        = cos(temp_theta/2.0);
    } 
    array[counter+1].position.target_pose.pose.position.x = x;
    array[counter+1].position.target_pose.pose.position.y = y;
    
}