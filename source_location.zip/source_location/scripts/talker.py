#!/usr/bin/python
# -*- coding: UTF-8 -*-

import rospy
from source_location.msg import position


def talker():
    pub = rospy.Publisher('chatter', position, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        position_num = position()
	rospy.loginfo(position_num)
        pub.publish(position_num)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
