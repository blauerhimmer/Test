#!/usr/bin/python
import rospy
from source_location.msg import alco_concentration


def callback(data):
    rospy.loginfo("alco_concentration is %f", data.concentration)

def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("chatter", alco_concentration, callback)
    rospy.spin()
if __name__ == '__main__':
    listener()
