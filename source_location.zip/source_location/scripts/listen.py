#!/usr/bin/python
import rospy
from source_location.msg import position


def callback(data):
    rospy.loginfo("position is %f %f", data.x,data.y)

def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("chatter", position, callback)
    rospy.spin()
if __name__ == '__main__':
    listener()
